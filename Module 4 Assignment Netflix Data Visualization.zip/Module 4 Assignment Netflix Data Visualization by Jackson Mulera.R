library(readr)
library(ggplot2)
library(dplyr)

df <- read_csv("D:/Accounts/Social Media\MSBA Nexford/Programming in R & Python/Module 4 Assignment Netflix Data Visualization/Destination/Netflix_shows_movies.csv")
head(df, 10)

#Handling Null Values

# Fill null values with the mode value in the country column since it is categorical data
mode_country <- names(sort(table(df$country), decreasing = TRUE))[1]
df$country <- ifelse(is.na(df$country), mode_country, df$country)

# Removing rows with null values in the column date_added
df <- df[!is.na(df$date_added), ]

# Using Impute functionality to fill blanks
columns_to_impute <- c('director', 'cast', 'rating', 'duration')
for (column in columns_to_impute) {
  df[[column]][is.na(df[[column]])] <- "Unknown"
  
  #Using Plotly to show visualization of distribution of ratings
  
  fig <- plot_ly(df, x = ~rating, type = 'histogram', title = "Rating distribution", color = ~rating)
  
  # Print any warnings
  warnings()
  